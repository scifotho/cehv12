# Section 01: Wireless Concepts

## Concepts
Wireless

[Definition](../definitions/definitions_W.md#wireless)

Bandwith

[Definition](../definitions/definitions_B.md#bandwith)

Wireless access point (WAP)

[Definition](../definitions/definitions_W.md#wireless-access-point)

IEEE 802.11

[Definition](../definitions/definitions_I.md#ieee-80211)

Service set identifier (SSID)

[Definition](../definitions/definitions_S.md#service-set-identifier)

801.1x

[Definition](../definitions/definitions_1.md#8011x)

RADIUS

[Definition](../definitions/definitions_R.md#radius)
