# Section 02: Wireless Encryption

## Wireless Encryption
Wired equivalent privacy

[Definition](../definitions/definitions_W.md#wired-equivalent-privacy)

Extensible authentication protocol (EAP)

[Definition](../definitions/definitions_E.md#extensible-authentication-protocol)

Wi-fi protected access (WPA)

[Definition](../definitions/definitions_W.md#wi-fi-protected-access)

Advanced encryption standard (AES)

[Definition](../definitions/definitions_A.md#advanced-encryption-standard)
