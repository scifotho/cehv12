# Module 16: Hacking Wireless Networks

## About

According to the official C|EH brochure this module covers the following material.

> Understand different types of wireless technologies, including
encryption, threats, hacking methodologies, hacking tools, Wi-Fi
security tools, and countermeasures.
