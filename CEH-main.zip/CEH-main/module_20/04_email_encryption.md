# Section 04: Email Encryption

## Email Encryption
Digital signature

[Definition](../definitions/definitions_D.md#digital-signature)

Secure sockets layer (SSL)

[Definition](../definitions/definitions_S.md#secure-sockets-layer)

Transport layer security (TLS)

[Definition](../definitions/definitions_T.md#transport-layer-security)

openssl

[Definition](../definitions/definitions_O.md#openssl)

Pretty good privacy (PGP)

[Definition](../definitions/definitions_P.md#pretty-good-privacy)

GNU privacy guard

[Definition](../definitions/definitions_G.md#gnu-privacy-guard)

Web of trust

[Definition](../definitions/definitions_W.md#web-of-trust)

Secure multipurpose internet mail extensions (S/MIME)
