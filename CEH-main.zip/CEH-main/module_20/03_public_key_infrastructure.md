# Section 03: Public Key Infrastructure

## Public Key Infrastructure
Public key infrastructure (PKI)

[Definition](../definitions/definitions_P.md#public-key-infrastructure)

Certificate authority (CA)

[Definition](../definitions/definitions_C.md#certificate-authority)

Registration authority (RA)

[Definition](../definitions/definitions_R.md#registration-authority)

Digicert

[Definition](../definitions/definitions_D.md#digicert)

Self signed certificate

[Definition](../definitions/definitions_S.md#self-signed-certificate)
