# Section 02: Host Discovery

## Address Resolution Protocol (ARP)
Address resolution protocol (ARP)

[Definition](../definitions/definitions_A.md#address-resolution-protocol)
