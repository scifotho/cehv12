# Section 01: Network Scanning Concepts

## Transmission Control Protocol (TCP)
Transmission control protocol (TCP)

[Definition](../definitions/definitions_T.md#transmission-control-protocol)

## nmap
nmap

[Definition](../definitions/definitions_N.md#nmap)

hping3

[Definition](../definitions/definitions_H.md#hping3)

Metasploit

[Definition](../definitions/definitions_M.md#metasploit)
