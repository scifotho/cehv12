# Module 03: Scanning Networks

## About

According to the official C|EH brochure this module covers the following material.

> Learn different network scanning techniques and countermeasures.
