# Definitions J

## Jamming
Radio jamming is the deliberate jamming, blocking or interference with wireless communications.
In some cases, jammers work by the transmission of radio signals that disrupt communications by decreasing the signal-to-noise ratio.

Links
- [https://en.wikipedia.org/wiki/Radio_jamming](https://en.wikipedia.org/wiki/Radio_jamming)

## John the Ripper
John the Ripper is a free password cracking software tool.
Originally developed for the Unix operating system, it can run on fifteen different platforms.

Links
- [https://github.com/openwall/john](https://github.com/openwall/john)
