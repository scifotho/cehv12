# Section 07: Footprinting through Social Engineering

## Social Engineering
Eavesdropping

[Definition](../definitions/definitions_E.md#eavesdropping)

Shoulder surfing

[Definition](../definitions/definitions_S.md#shoulder-surfing)

Dumpster diving

[Definition](../definitions/definitions_D.md#dumpster-diving)

Impersonation / impersonator

[Definition](../definitions/definitions_I.md#impersonation)

OSINT Framework

[Definition](../definitions/definitions_O.md#osint-framework)
