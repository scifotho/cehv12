# Section 08: Footprinting Tools and Countermeasures

## Tools
Recon-ng

[Definition](../definitions/definitions_R.md#recon-ng)

## Countermeasures
Split DNS

[Definition](../definitions/definitions_S.md#split-dns)

Some countermeasures are listed below.

- Restrict network access to social media from the corporate network.
- Security awereness training
- Harden web servers
- Split DNS into internal and external servers or use split DNS.
- Disable unused protocols
- Have a good on and offboarding strategy
