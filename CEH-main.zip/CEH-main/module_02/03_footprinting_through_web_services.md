# Section 03: Footprinting through Web Services

## Finding Company Domains
Top-level domain (TLD)

[Definition](../definitions/definitions_T.md#top-level-domain)

Sublist3r

[Definition](../definitions/definitions_S.md#sublist3r)

Pentest-tools

[Definition](../definitions/definitions_P.md#pentest-tools)

## LinkedIn
theHarvester

[Definition](../definitions/definitions_T.md#theharvester)

## The Dark Web
The dark web

[Definition](../definitions/definitions_T.md#the-dark-web)

Tor
 
[Definition](../definitions/definitions_T.md#tor)

## OS Determination
Shodan

[Definition](../definitions/definitions_S.md#shodan)

## Competitive Intelligence
Competitive Intelligence

[Definition](../definitions/definitions_C.md#competitive-intelligence)

## Other Techniques
Google earth

[Definition](../definitions/definitions_G.md#google-earth)

Google finance

[Definition](../definitions/definitions_G.md#google-finance)
