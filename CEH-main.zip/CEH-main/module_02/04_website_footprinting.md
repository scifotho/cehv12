# Section 04: Website Footprinting

## Website Footprinting
Burp suite

[Definition](../definitions/definitions_B.md#burp-suite)

Website footprinting
- Examining HTML source code
- Examining cookies

## Web Spider
Web spider

[Definition](../definitions/definitions_W.md#web-spider)

## Extracting Information from archive.org
Archive org

[Definition](../definitions/definitions_A.md#archive-org)

## Metadata Extraction Tools
ExifTool

[Definition](../definitions/definitions_E.md#exiftool)
