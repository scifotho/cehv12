# Section 03: Maintaining Access

## Maintaining Access
Backdoor

[Definition](../definitions/definitions_B.md#backdoor)

Keylogger / Keystroke logger

[Definition](../definitions/definitions_K.md#keylogger)

Spyware

[Definition](../definitions/definitions_S.md#spyware)

Rootkit

[Definition](../definitions/definitions_R.md#rootkit)

Steganography

[Definition](../definitions/definitions_S.md#steganography)
