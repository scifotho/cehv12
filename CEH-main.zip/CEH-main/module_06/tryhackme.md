# TryHackMe

Links
- [https://tryhackme.com/room/introtoshells](https://tryhackme.com/room/introtoshells)
- [https://tryhackme.com/room/commonlinuxprivesc](https://tryhackme.com/room/commonlinuxprivesc)
- [https://tryhackme.com/room/linuxprivesc](https://tryhackme.com/room/linuxprivesc)
- [https://tryhackme.com/room/linprivesc](https://tryhackme.com/room/linprivesc)
- [https://tryhackme.com/room/windowsprivesc20](https://tryhackme.com/room/windowsprivesc20)