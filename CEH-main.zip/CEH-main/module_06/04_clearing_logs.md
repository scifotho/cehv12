# Section 04: Clearing Logs

## Covering Tracks
Covering tracks is one of the most stage during system hacking. during this stage, the attacker tries to cover and avoid being detected, or “traced out,” by covering all track, or logs, generated while gaining access to the target networks or computer.

Covering bash shell tracks
- Disable history
```shell
export HISTSIZE=0
```
- Clearing history
```shell
history -c
```