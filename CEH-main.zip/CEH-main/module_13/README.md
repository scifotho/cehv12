# Module 13: Hacking Web Servers

## About

According to the official C|EH brochure this module covers the following material.

> Learn about web server attacks, including a comprehensive attack
methodology used to audit vulnerabilities in web server infrastructures
and countermeasures.
