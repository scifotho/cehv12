# Section 01: Web Server Concepts

## Web Server Concepts
Web server

Hypertext transer protocol (HTTP)

[Definition](../definitions/definitions_H.md#hypertext-transfer-protocol)

Virtual hosting

[Definition](../definitions/definitions_V.md#virtual-hosting)

LAMP (Linux Apache MySQL PHP) stack

[Definition](../definitions/definitions_L.md#lamp-stack)

Internet information services (IIS)

[Definition](../definitions/definitions_I.md#internet-information-services)

Website defacement

[Definition](../definitions/definitions_W.md#website-defacement)
