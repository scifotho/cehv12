# Section 02: Container Technology

## Container Technology
Containerization

[Definition](../definitions/definitions_C.md#containerization)

Docker

[Definition](../definitions/definitions_D.md#docker)

Kubernetes

[Definition](../definitions/definitions_K.md#kubernetes)

Virtual machine (VM)

[Definition](../definitions/definitions_V.md#virtual-machine)
