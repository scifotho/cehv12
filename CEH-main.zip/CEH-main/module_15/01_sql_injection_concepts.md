# Section 01: SQL Injection Concepts

## Concepts
Structured query language (SQL)

[Definition](../definitions/definitions_S.md#structured-query-language)

Structured query language (SQL) injection

[Definition](../definitions/definitions_S.md#structured-query-language-injection)

Remote code execution (RCE)

[Definition](../definitions/definitions_R.md#remote-code-execution)
