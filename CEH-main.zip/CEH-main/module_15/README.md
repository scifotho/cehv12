# Module 15: SQL Injections

## About

According to the official C|EH brochure this module covers the following material.

> Learn about SQL injection attacks, evasion techniques, and SQL
injection countermeasures.
