# Section 03: Hacking Concepts

## Hacking

Hacker

[Definition](../definitions/definitions_H.md#hacker)

Script kiddie

[Definition](../definitions/definitions_S.md#script-kiddie)

Hacktivist

[Definition](../definitions/definitions_H.md#hacktivist)

Insider

[Definition](../definitions/definitions_I.md#insider)

Organized crime

[Definition](../definitions/definitions_O.md#organized-crime)
