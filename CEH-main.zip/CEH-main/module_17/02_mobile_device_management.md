# Section 02: Mobile Device Management

## Mobile Device Management
Acceptable use policy

[Definition](../definitions/definitions_A.md#acceptable-use-policy)

Mobile device management (MDM)

[Definition](../definitions/definitions_M.md#mobile-device-management)
