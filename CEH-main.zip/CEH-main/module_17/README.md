# Module 17: Hacking Mobile Platforms

## About

According to the official C|EH brochure this module covers the following material.

> Learn Mobile platform attack vector, android and iOS hacking, mobile
device management, mobile security guidelines, and security tools.
