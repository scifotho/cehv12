# Section 03: DDoS Attack Countermeasures

## Countermeasures
- Baselining the activity on the network.
- Shut down services.
- Ingress or egress filtering.

Rate limiting

[Definition](../definitions/definitions_R.md#rate-limiting)

Load balancing

[Definition](../definitions/definitions_L.md#load-balancing)

Bandwith throttling

[Definition](../definitions/definitions_B.md#bandwith-throttling)
