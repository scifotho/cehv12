# Section 01: DoS DDoS Concepts

## Concepts
Denial of service (DoS) attack

[Definition](../definitions/definitions_D.md#denial-of-service-attack)

Distributed denial of service

[Definition](../definitions/definitions_D.md#distributed-denial-of-service-attack)

Botnet

[Definition](../definitions/definitions_B.md#botnet)

Internet relay chat (IRC)

[Definition](../definitions/definitions_I.md#internet-relay-chat)
