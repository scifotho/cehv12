# Module 10: Denial-of-Service

## About

According to the official C|EH brochure this module covers the following material.

> Learn about different Denial of Service (DoS) and Distributed DoS
(DDoS) attack techniques, as well as the tools used to audit a target and
devise DoS and DDoS countermeasures and protections.
