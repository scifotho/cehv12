# Section 01: Social Engineering Concepts

## Social Engineering
Social Engineering

[Definition](../definitions/definitions_S.md#social-engineering)

Different behaviors that categorize social engineering are the following
- Authority
- Intimidation
- Consensus
- Scarcity
- Urgency
- Familiary
- Trust
