# Section 02: Social Engineering Concepts

## Human Based Social Engineering
Impersonation / Impersonator

[Definition](../definitions/definitions_I.md#impersonation)

Eavesdropping

[Definition](../definitions/definitions_E.md#eavesdropping)

Shoulder surfing

[Definition](../definitions/definitions_S.md#shoulder-surfing)

Dumpster diving

[Definition](../definitions/definitions_D.md#dumpster-diving)

Piggybacking

[Definition](../definitions/definitions_P.md#piggybacking)

Elicitation
 
[Definition](../definitions/definitions_E.md#elicitation)

Pretexting

[Definition](../definitions/definitions_P.md#pretexting)

Wardriving

[Definition](../definitions/definitions_W.md#wardriving)

## Computer Based Social Engineering
Phishing

[Definition](../definitions/definitions_P.md#phishing)

Spam

[Definition](../definitions/definitions_S.md#spam)
