# Section 03: DHCP Attacks

## Dynamic Host Configuration Protocol
Dynamic host configuration protocol (DHCP)

[Definition](../definitions/definitions_D.md#dynamic-host-configuration-protocol)
