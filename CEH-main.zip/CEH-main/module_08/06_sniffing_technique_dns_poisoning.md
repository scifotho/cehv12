# Section 06: DNS poisoning

## DNS poisoning
Domain name system (DNS)

[Definition](../definitions/definitions_D.md#domain-name-system)

DNS spoofing

[Definition](../definitions/definitions_D.md#domain-name-system-spoofing)
