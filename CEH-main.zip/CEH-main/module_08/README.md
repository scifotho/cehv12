# Module 08: Sniffing

## About

According to the official C|EH brochure this module covers the following material.

> Learn about packet-sniffing techniques and how to use them to discover
network vulnerabilities, as well as countermeasures to defend against
sniffing attacks.
