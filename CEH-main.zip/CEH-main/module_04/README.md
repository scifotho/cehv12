# Module 04: Enumeration

## About

According to the official C|EH brochure this module covers the following material.

> Learn various enumeration techniques, such as Border Gateway
Protocol (BGP) and Network File Sharing (NFS) exploits, and associated
countermeasures.
