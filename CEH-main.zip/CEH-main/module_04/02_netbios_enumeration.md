# Section 02: NetBIOS Enumeration

## NetBIOS
NetBIOS

[Definition](../definitions/definitions_N.md#netbios)
