# Section 03: SNMP Enumeration

## SNMP
Simple network management protocol (SNMP)

[Definition](../definitions/definitions_S.md#simple-network-management-protocol)
