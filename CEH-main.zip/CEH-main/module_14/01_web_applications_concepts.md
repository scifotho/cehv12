# Section 01: Web Applications Concepts

## Concepts
Web application

[Definition](../definitions/definitions_W.md#web-application)

Uniform resource locator (URL)

[Definition](../definitions/definitions_U.md#uniform-resource-locator)
