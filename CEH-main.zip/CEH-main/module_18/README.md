# Module 18: IoT and OT Hacking

## About

According to the official C|EH brochure this module covers the following material.

> Learn different types of IoT and OT attacks, hacking methodology,
hacking tools, and countermeasures.
