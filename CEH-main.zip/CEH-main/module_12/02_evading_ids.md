# Section 02: Evading IDS

## Evading IDS
Obfuscation

[Definition](../definitions/definitions_O.md#obfuscation)

Packet fragmentation

[Definition](../definitions/definitions_I.md#internet-protocol-fragmentation)

Encryption

[Definition](../definitions/definitions_E.md#encryption)
