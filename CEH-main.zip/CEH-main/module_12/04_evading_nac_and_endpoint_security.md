# Section 04: Evading NAC and Endpoint Security

## Evading NAC and Endpoint Security
VLAN hopping

[Definition](../definitions/definitions_V.md#vlan-hopping)
