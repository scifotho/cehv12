# Section 02: APT Concepts

## Advanced Persistent Threats (APT)

[Definition](../definitions/definitions_A.md#advanced-persistent-threat)
