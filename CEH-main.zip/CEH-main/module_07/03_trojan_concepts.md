# Section 03: Trojan Concepts

## Concepts
Trojan horse

[Definition](../definitions/definitions_T.md#trojan-horse)

Remote access trojan (RAT)

[Definition](../definitions/definitions_R.md#remote-access-trojan)
